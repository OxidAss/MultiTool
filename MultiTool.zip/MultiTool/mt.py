import os
from os import system
import webbrowser
import selenium
from selenium import webdriver

print("MultiTool by OdixAss(GitHub)/Prof1Leak in other pages.\n\nAll functions:\n   1 - Deleting tool(path system)\n   2 - Open any link in FireFox(Use a default FireFox path)\n   3 - Open Simple Unlocker\n\nFor a contact: @Prof1LeakLike - Telegram")
choose = input("Choose a number: ")
print(choose)

if choose == "1":
    path = input("Type a path to program(deleting EVERYTING): ")
    print(path)
    print("Done! If you have no error, restart the window for use any other options.")
    os.remove(path)

if choose == "2":
    link_request = input("Enter a link: ")
    print(link_request)
    # FireFox
    webbrowser.register('firefox_private', None, webbrowser.BackgroundBrowser("C:\Program Files\Mozilla Firefox\private_browsing.exe"))
    webbrowser.get("firefox_private").open(link_request)
    # Chrome
    webbrowser.register('chrome_incognito', None, webbrowser.GenericBrowser(["C:\Program Files\Google\Chrome\Application\chrome.exe", "-incognito", "%s"]), preferred=True)
    webbrowser.get("chrome_incognito").open(link_request)

    print("Done! Restart programm for use any other options")

if choose == "3":
    os.startfile("other tools\SU\SU.exe")

    print("Done! Restart for use any other programms.")