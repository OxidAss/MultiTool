MultiTool by Prof1Leak/OdixAss(GitHub).

Mt have 2 function:
    - Delete tool using path system
    - Open any links in incognito

For use 3 function, go to MultiTool\other tools\SU\ and open SU.exe file, you can chek it on VM or other virtual machine, have only one error - Russian Language

REQUIER TO READ FOR USE INCOGNITO BROWSER MODE!

MultiTool now support only 2 browser - Chrome and FireFox, in tool use default path to both browser, if you have both browser, they open both too

If you seen any error - you can write this on page of this project.